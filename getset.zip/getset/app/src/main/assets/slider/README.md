sliding_puzzle
==============

A simple sliding blocks puzzle game. You can also create your own puzzle and then click on "Get Url" to get 
a link which will recreate the puzzle whenever someone clicks on it. 

Here's a tiny commentary about the coding style. I have, in a long time, deviated from using separate screens 
and provided you with a game in its first screen. I was trying to emulate the actual hardware toy of 
the same game which is just there and does not have a Main Menu. One of the consequences of this approach 
is a few lines (maybe more than a few) of repeated code and inefficient algorithms. 
If you go through the code of game.js file, you'll see a lot of places where you may go "WHY!?" and in certain cases, 
I've genuinely forgotten why,  even though the I made the whole game in less than a day.  
So please forgive the crass coding and try and enjoy the game!

